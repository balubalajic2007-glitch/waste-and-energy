"""Chhat Solar: Lambda handler. POST /plan {"units": 300, "tariff": 7, "roof_m2": 30, "region": "south"}"""
import json, os, time

RULES = json.load(open(os.path.join(os.path.dirname(__file__), "rules.json")))
TABLE = os.environ.get("TABLE_NAME")
REG = {r["id"]: r for r in RULES["regions"]}


def subsidy(kw):
    s = RULES["subsidy"]
    amt = s["per_kw_first2"] * min(kw, 2) + s["per_kw_third"] * min(max(kw - 2, 0), 1)
    return min(amt, s["cap"])


def plan(units, tariff, roof_m2, region):
    y = REG[region]["yield"]
    need = units * 12 / y
    kw = min(need, roof_m2 / RULES["area_per_kw"], RULES["max_kw"])
    kw = round(kw * 2) / 2 if kw >= 1 else 0
    if kw == 0:
        return {"kw": 0, "reason": "Roof too small or usage too low for a rooftop system."}
    gen = kw * y
    saving = min(gen, units * 12) * tariff
    cost = kw * RULES["cost_per_kw"]
    sub = subsidy(kw)
    net = cost - sub
    return {"kw": kw, "annual_kwh": round(gen), "annual_saving_inr": round(saving),
            "cost_inr": round(cost), "subsidy_inr": round(sub), "you_pay_inr": round(net),
            "payback_years": round(net / saving, 1) if saving else None,
            "co2_tonnes_per_year": round(gen * RULES["grid_co2"] / 1000, 2)}


def handler(event, _ctx=None):
    try:
        b = json.loads(event.get("body") or "{}")
        units, tariff, roof = float(b["units"]), float(b.get("tariff", 7)), float(b["roof_m2"])
        region = b.get("region", "north")
        if region not in REG or not (0 < units <= 5000) or not (0 < tariff <= 30) or not (0 <= roof <= 2000):
            raise ValueError
    except (KeyError, ValueError, TypeError):
        return {"statusCode": 400, "body": json.dumps({"error": "need units, roof_m2, valid region"})}
    result = plan(units, tariff, roof, region)
    if TABLE and result["kw"]:
        import boto3
        boto3.resource("dynamodb").Table(TABLE).put_item(Item={
            "region": region, "ts": int(time.time()), "kw": str(result["kw"]),
            "co2": str(result["co2_tonnes_per_year"])})
    return {"statusCode": 200, "headers": {"Content-Type": "application/json"}, "body": json.dumps(result)}
